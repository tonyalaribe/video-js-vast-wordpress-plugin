The files in this directory need to be added to svn/assets, NOT
svn/trunk/assets, which is where the normal SVN release process will put them.
It's fine if they exist in both places, but make sure that you copy them to
svn/assets if you update them.
