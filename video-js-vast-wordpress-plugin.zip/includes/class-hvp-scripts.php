<?php
// Exit if accessed directly
if (!defined('ABSPATH')) exit;

/**
 * Scripts Class
 *
 * Handles adding scripts functionality to the admin pages
 * as well as the front pages.
 *
 * @package True Pundit Video Player
 * @since 1.0.0
 */

class Hvp_Scripts {

    //class constructor
    function __construct()
    {
        
    }
    
    /**
     * Enqueue Scripts on Admin Side
     *
     * @package True Pundit Video Player
     * @since 1.0.0
     */
    public function hvp_admin_scripts() {

        if(current_user_can('manage_options') || current_user_can('edit_posts')) {
            // admin script
            wp_register_script('hvp_admin_script', HVP_INC_URL . '/js/hvp-admin.js', array('jquery'), HVP_VERSION);
            wp_enqueue_script('hvp_admin_script');
            
            // Register admin style for shortcode button and poup
            wp_register_style('hvp_admin_style',  HVP_INC_URL . '/css/hvp-admin-style.css',HVP_VERSION);
            wp_enqueue_style('hvp_admin_style');

            //wp_register_script('hvp_ga_script', HVP_INC_URL . '/js/ga.js', HVP_VERSION);
            //wp_enqueue_script('hvp_ga_script');
            
            if (is_admin ()){
                wp_enqueue_media();
            }
        }
    }

    /**
     * Enqueue Scripts on front Side
     *
     * @package True Pundit Video Player
     * @since 1.0.0
     */
    public function hvp_public_scripts(){
        global $post;        

        // Simple video js
        // $customer = get_option('hvp-cdn-customerid');
        // if ($customer) {
            // wp_register_script('hvp_video_script', HVP_INC_URL . "/js/hola/hola_player.dev.js", array(), null);
        // }

        // // Youtube videojs support
        // wp_register_script('hvp_youtube_video_script', HVP_INC_URL . '/js/Youtube.js', array(), HVP_VERSION);

        // // Vimeo videojs support
        // wp_register_script('hvp_vimeo_video_script', HVP_INC_URL . '/js/Vimeo.js', array(), HVP_VERSION);

        // // IMA ADS SDK loader
        // wp_register_script('hvp_ima_ads_sdk_script', '//imasdk.googleapis.com/js/sdkloader/ima3.js', array(), HVP_VERSION);

        //wp_register_script('hvp_video_script', "//vjs.zencdn.net/5.19/video.min.js", array(), null);
        //wp_register_script('hvp_video_script2', HVP_INC_URL ."/true-pundit/videojs_5.vast.vpaid.min.js", array(), HVP_VERSION);
   }



    /**
     * Enqueue styles on front Side
     *
     * @package True Pundit Video Player
     * @since 1.0.0
     */
    public function hvp_public_styles() {
        wp_register_style('hvp_public_styles', "//vjs.zencdn.net/5.19/video-js.min.css", HVP_VERSION);
        wp_register_style('hvp_public_styles2',  HVP_INC_URL . '/true-pundit/videojs.vast.vpaid.min.css',HVP_VERSION);
        wp_register_style('hvp_public_styles3',  HVP_INC_URL . '/true-pundit/bin/videojs-skin-flat/videojs-skin-flat.min.css',HVP_VERSION);
        wp_enqueue_style('hvp_public_styles');
        wp_enqueue_style('hvp_public_styles2');
        wp_enqueue_style('hvp_public_styles3');
    }
    
    /**
     * Adding Hooks
     *
     * Adding hooks for the styles and scripts.
     *
     * @package True Pundit Video Player
     * @since 1.0.0
     */
    function add_hooks(){
        //add admin scripts
        add_action('admin_enqueue_scripts', array($this, 'hvp_admin_scripts'));

        //add public scripts
        add_action('wp_enqueue_scripts', array($this, 'hvp_public_scripts'));

        //add public styles
        add_action('wp_enqueue_scripts', array($this, 'hvp_public_styles'));

        wp_enqueue_script('hvp_video_script', HVP_INC_URL ."/true-pundit/videojs.js", false);
        wp_enqueue_script('hvp_video_script2', HVP_INC_URL ."/true-pundit/videojs_5.vast.vpaid.min.js", false);
    }
}
?>
